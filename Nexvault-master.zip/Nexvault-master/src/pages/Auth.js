import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import {
  Mail, Lock, Eye, EyeOff, ArrowRight,
  User, Phone, CheckCircle, Shield, Zap, BarChart2, Target,
} from 'lucide-react';
import { FcGoogle } from 'react-icons/fc';
import { FaApple } from 'react-icons/fa';
import { useAuth } from '../context/AuthContext';
import './Auth.css';

function validateEmail(email) {
  // RFC 5322 simplified — covers all real-world email formats
  return /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/.test(email.trim());
}

function validatePassword(pw) {
  return pw.length >= 8;
}

function validateName(name) {
  // Letters, spaces, hyphens, apostrophes only — min 2 chars
  return /^[a-zA-ZÀ-ÿ' \-]{2,}$/.test(name.trim());
}

function validatePhone(phone) {
  // Accepts: +1 (555) 000-0000 / +44 7911 123456 / 0612345678 etc.
  // Strips spaces, dashes, dots, parens then checks 7–15 digits with optional leading +
  const stripped = phone.replace(/[\s\-().]/g, '');
  return /^\+?[0-9]{7,15}$/.test(stripped);
}

function getPasswordStrength(pw) {
  if (!pw) return { label: '', color: 'var(--border)', score: 0 };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^a-zA-Z0-9]/.test(pw)) score++;
  if (score <= 1) return { label: 'Weak', color: 'var(--danger)', score };
  if (score <= 3) return { label: 'Medium', color: 'var(--warning)', score };
  return { label: 'Strong', color: 'var(--success)', score };
}

export function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '', remember: false });
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const justRegistered = new URLSearchParams(window.location.search).get('registered') === 'true';

  const validate = () => {
    const e = {};
    if (!form.email.trim()) e.email = 'Email is required.';
    else if (!validateEmail(form.email)) e.email = 'Enter a valid email address (e.g. you@example.com).';
    if (!form.password) e.password = 'Password is required.';
    else if (form.password.length < 8) e.password = 'Password must be at least 8 characters.';
    return e;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);

    try {
      const response = await login(form.email.trim(), form.password);
      if (response.success && response.requiresTwoFactor) {
        navigate('/verify-2fa', { state: { email: form.email.trim(), method: response.twoFactorMethod } });
      } else if (response.success) {
        navigate('/dashboard');
      } else {
        setErrors({ form: response.message || 'Invalid email or password.' });
      }
    } catch (err) {
      setErrors({ form: err.message || 'Login failed. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: <Shield size={16} />, label: 'Bank-grade security' },
    { icon: <Zap size={16} />, label: 'Instant global transfers' },
    { icon: <BarChart2 size={16} />, label: 'Real-time analytics' },
    { icon: <Target size={16} />, label: 'Cashback rewards' },
  ];

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="auth-left-content">
          <div className="landing-logo" style={{ marginBottom: 40 }}>
            <div className="landing-logo-mark">N</div>
            <span style={{ color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22 }}>NexVault</span>
          </div>
          <h2>Welcome back to the future of finance.</h2>
          <p>Manage your money smarter. Send, receive, and grow your wealth with the power of distributed cloud banking.</p>
          <div className="auth-features">
            {features.map((f, i) => (
              <div key={i} className="auth-feature-item">
                {f.icon} {f.label}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-form-wrap animate-fade">
          <div className="auth-form-header">
            <h1>Sign in</h1>
            <p>Welcome back! Enter your details to continue.</p>
          </div>

          {justRegistered && (
            <div className="alert alert-success" style={{ marginBottom: 16 }}>
              Account created! Sign in to access your dashboard.
            </div>
          )}

          {errors.form && (
            <div className="alert alert-danger" style={{ marginBottom: 16 }}>
              {errors.form}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <div className="input-icon-wrap">
                <Mail size={16} className="input-icon" />
                <input
                  type="email"
                  className={`form-control input-with-icon ${errors.email ? 'input-error' : ''}`}
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  aria-describedby={errors.email ? 'email-error' : undefined}
                />
              </div>
              {errors.email && <span id="email-error" className="field-error">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
                Password
                <a href="#" style={{ fontWeight: 400, fontSize: 13 }}>Forgot password?</a>
              </label>
              <div className="input-icon-wrap">
                <Lock size={16} className="input-icon" />
                <input
                  type={showPw ? 'text' : 'password'}
                  className={`form-control input-with-icon input-with-icon-right ${errors.password ? 'input-error' : ''}`}
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  aria-describedby={errors.password ? 'pw-error' : undefined}
                />
                <button type="button" className="input-icon-right" onClick={() => setShowPw(v => !v)} aria-label="Toggle password">
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && <span id="pw-error" className="field-error">{errors.password}</span>}
            </div>

            <div className="auth-remember">
              <label>
                <input type="checkbox" checked={form.remember} onChange={e => setForm({ ...form, remember: e.target.checked })} />
                <span>Remember me for 30 days</span>
              </label>
            </div>

            <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
              {loading ? <><span className="spinner" />Signing in...</> : <><span>Sign In</span><ArrowRight size={16} /></>}
            </button>
          </form>

          <div className="auth-divider"><span>or continue with</span></div>
          <div className="auth-social">
            <button className="auth-social-btn"><FcGoogle size={18} /> Google</button>
            <button className="auth-social-btn"><FaApple size={18} /> Apple</button>
          </div>

          <div className="auth-switch">
            Don't have an account? <Link to="/register">Create one free</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Verify2FA() {
  const navigate = useNavigate();
  const location = useLocation();
  const { verifyTwoFactor } = useAuth();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const email = location.state?.email || '';
  const method = location.state?.method || 'email';

  useEffect(() => {
    if (!email) {
      navigate('/login');
    }
  }, [email, navigate]);

  const handleVerify = async (e) => {
    e.preventDefault();
    if (!code.trim()) {
      setError('Please enter the verification code sent to your email.');
      return;
    }
    setError(null);
    setLoading(true);

    try {
      const response = await verifyTwoFactor(email, code.trim());
      if (response.success) {
        navigate('/dashboard');
      } else {
        setError(response.message || 'Invalid verification code.');
      }
    } catch (err) {
      setError(err.message || 'Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-left">
        <div className="auth-left-content">
          <div className="landing-logo" style={{ marginBottom: 40 }}>
            <div className="landing-logo-mark">N</div>
            <span style={{ color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22 }}>NexVault</span>
          </div>
          <h2>Two-factor authentication</h2>
          <p>Enter the code we sent to <strong>{email}</strong> to complete login.</p>
          <div className="auth-features">
            <div className="auth-feature-item"><Shield size={16} /> Secure sign in</div>
            <div className="auth-feature-item"><Zap size={16} /> Verified on every login</div>
            <div className="auth-feature-item"><Mail size={16} /> Code delivered via {method}</div>
          </div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-form-wrap animate-fade">
          <div className="auth-form-header">
            <h1>Verify your login</h1>
            <p>Enter the 6-digit code from your email.</p>
          </div>

          {error && (
            <div className="alert alert-danger" style={{ marginBottom: 16 }}>
              {error}
            </div>
          )}

          <form onSubmit={handleVerify} noValidate>
            <div className="form-group">
              <label className="form-label">Verification Code</label>
              <input
                type="text"
                className={`form-control ${error ? 'input-error' : ''}`}
                placeholder="123456"
                value={code}
                onChange={e => setCode(e.target.value)}
              />
            </div>

            <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
              {loading ? <><span className="spinner" /> Verifying...</> : 'Verify and continue'}
            </button>
          </form>

          <div className="auth-switch" style={{ marginTop: 18 }}>
            <button type="button" className="btn btn-ghost" onClick={() => navigate('/login')}>
              Back to login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Register() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [errors, setErrors] = useState({});
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    password: '', confirm: '', agree: false,
  });

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const validateStep1 = () => {
    const e = {};
    if (!form.firstName.trim()) e.firstName = 'First name is required.';
    else if (!validateName(form.firstName)) e.firstName = 'Enter a valid first name (letters only, min 2 chars).';

    if (!form.lastName.trim()) e.lastName = 'Last name is required.';
    else if (!validateName(form.lastName)) e.lastName = 'Enter a valid last name (letters only, min 2 chars).';

    if (!form.email.trim()) e.email = 'Email is required.';
    else if (!validateEmail(form.email)) e.email = 'Enter a valid email address (e.g. you@example.com).';

    if (!form.phone.trim()) e.phone = 'Phone number is required.';
    else if (!validatePhone(form.phone)) e.phone = 'Enter a valid phone number (e.g. +1 555 000 0000).';

    return e;
  };

  const validateStep2 = () => {
    const e = {};
    if (!form.password) e.password = 'Password is required.';
    else if (form.password.length < 8) e.password = 'Password must be at least 8 characters.';
    else if (!/[A-Z]/.test(form.password)) e.password = 'Password must contain at least one uppercase letter.';
    else if (!/[0-9]/.test(form.password)) e.password = 'Password must contain at least one number.';

    if (!form.confirm) e.confirm = 'Please confirm your password.';
    else if (form.password !== form.confirm) e.confirm = 'Passwords do not match.';

    if (!form.agree) e.agree = 'You must accept the terms to continue.';
    return e;
  };

  const handleNext = (e) => {
    e.preventDefault();
    if (step === 1) {
      const errs = validateStep1();
      if (Object.keys(errs).length) { setErrors(errs); return; }
      setErrors({});
      setStep(2);
      return;
    }
    const errs = validateStep2();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    setTimeout(() => { setLoading(false); navigate('/login?registered=true'); }, 1200);
  };

  const pwStrength = getPasswordStrength(form.password);
  const pwColor = pwStrength.color;

  const steps = ['Create your account', 'Sign in', 'Verify & transact'];

  return (
    <div className="auth-page">
      <div className="auth-left auth-left-register">
        <div className="auth-left-content">
          <div className="landing-logo" style={{ marginBottom: 40 }}>
            <div className="landing-logo-mark">N</div>
            <span style={{ color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 22 }}>NexVault</span>
          </div>
          <h2>Start your financial journey in 2 minutes.</h2>
          <p>Open a NexVault account today — free, secure, and powerful. No hidden fees, no minimum balance.</p>
          <div className="auth-steps-visual">
            {steps.map((s, i) => (
              <div key={i} className="auth-step-vis">
                <div className={`auth-step-num ${step > i ? 'done' : step === i + 1 ? 'curr' : ''}`}>
                  {step > i ? <CheckCircle size={14} /> : i + 1}
                </div>
                <span>{s}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-form-wrap animate-fade">
          <div className="auth-form-header">
            <h1>{step === 1 ? 'Create Account' : 'Secure your account'}</h1>
            <p>{step === 1 ? 'Step 1 of 2 — Personal information' : 'Step 2 of 2 — Set your password'}</p>
          </div>

          <div className="auth-progress">
            <div className="auth-progress-fill" style={{ width: `${step * 50}%` }} />
          </div>

          <form onSubmit={handleNext} noValidate style={{ marginTop: 24 }}>
            {step === 1 && <>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <div className="form-group">
                  <label className="form-label">First Name</label>
                  <div className="input-icon-wrap">
                    <User size={16} className="input-icon" />
                    <input className={`form-control input-with-icon ${errors.firstName ? 'input-error' : ''}`} placeholder="John" value={form.firstName} onChange={e => update('firstName', e.target.value)} />
                  </div>
                  {errors.firstName && <span className="field-error">{errors.firstName}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Last Name</label>
                  <div className="input-icon-wrap">
                    <User size={16} className="input-icon" />
                    <input className={`form-control input-with-icon ${errors.lastName ? 'input-error' : ''}`} placeholder="Doe" value={form.lastName} onChange={e => update('lastName', e.target.value)} />
                  </div>
                  {errors.lastName && <span className="field-error">{errors.lastName}</span>}
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Email Address</label>
                <div className="input-icon-wrap">
                  <Mail size={16} className="input-icon" />
                  <input type="email" className={`form-control input-with-icon ${errors.email ? 'input-error' : ''}`} placeholder="you@example.com" value={form.email} onChange={e => update('email', e.target.value)} />
                </div>
                {errors.email && <span className="field-error">{errors.email}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Phone Number</label>
                <div className="input-icon-wrap">
                  <Phone size={16} className="input-icon" />
                  <input type="tel" className={`form-control input-with-icon ${errors.phone ? 'input-error' : ''}`} placeholder="+1 (555) 000-0000" value={form.phone} onChange={e => update('phone', e.target.value)} />
                </div>
                {errors.phone && <span className="field-error">{errors.phone}</span>}
              </div>
            </>}

            {step === 2 && <>
              <div className="form-group">
                <label className="form-label">Password</label>
                <div className="input-icon-wrap">
                  <Lock size={16} className="input-icon" />
                  <input
                    type={showPw ? 'text' : 'password'}
                    className={`form-control input-with-icon input-with-icon-right ${errors.password ? 'input-error' : ''}`}
                    placeholder="Min 8 characters"
                    value={form.password}
                    onChange={e => update('password', e.target.value)}
                  />
                  <button type="button" className="input-icon-right" onClick={() => setShowPw(v => !v)} aria-label="Toggle password">
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {form.password && (
                  <div className="auth-password-strength">
                    <div className="pws-bar" style={{ background: pwColor, width: `${(pwStrength.score / 5) * 100}%` }} />
                    <span style={{ color: pwColor }}>{pwStrength.label}</span>
                  </div>
                )}
                <div className="auth-pw-hints">
                  <span className={form.password.length >= 8 ? 'hint-ok' : 'hint-off'}>8+ characters</span>
                  <span className={/[A-Z]/.test(form.password) ? 'hint-ok' : 'hint-off'}>Uppercase</span>
                  <span className={/[0-9]/.test(form.password) ? 'hint-ok' : 'hint-off'}>Number</span>
                  <span className={/[^a-zA-Z0-9]/.test(form.password) ? 'hint-ok' : 'hint-off'}>Symbol</span>
                </div>
                {errors.password && <span className="field-error">{errors.password}</span>}
              </div>
              <div className="form-group">
                <label className="form-label">Confirm Password</label>
                <div className="input-icon-wrap">
                  <Lock size={16} className="input-icon" />
                  <input type="password" className={`form-control input-with-icon ${errors.confirm ? 'input-error' : ''}`} placeholder="Repeat password" value={form.confirm} onChange={e => update('confirm', e.target.value)} />
                </div>
                {errors.confirm && <span className="field-error">{errors.confirm}</span>}
              </div>
              <div className="auth-agree">
                <label>
                  <input type="checkbox" checked={form.agree} onChange={e => update('agree', e.target.checked)} />
                  <span>I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></span>
                </label>
                {errors.agree && <span className="field-error" style={{ display: 'block', marginTop: 4 }}>{errors.agree}</span>}
              </div>
            </>}

            <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
              {step === 2 && (
                <button type="button" className="btn btn-outline btn-lg" style={{ flex: 1 }} onClick={() => { setStep(1); setErrors({}); }}>
                  ← Back
                </button>
              )}
              <button type="submit" className="btn btn-primary btn-lg" style={{ flex: 1 }} disabled={loading}>
                {loading ? <><span className="spinner" />Creating...</> : step === 1 ? <><span>Continue</span><ArrowRight size={16} /></> : <><span>Create Account</span><ArrowRight size={16} /></>}
              </button>
            </div>
          </form>

          <div className="auth-switch">
            Already have an account? <Link to="/login">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
